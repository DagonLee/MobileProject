package com.example.registeration;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class DetailCourseAdapter extends BaseAdapter {

    private Context context;
    private List<DetailCourse> detailCourseList;

    public DetailCourseAdapter(Context context, List<DetailCourse> detailCoursesList) {
        this.context = context;
        this.detailCourseList = detailCourseList;
    }

    @Override
    public int getCount() {
        return detailCourseList.size();
    }

    @Override
    public Object getItem(int position) {
        return detailCourseList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View v = View.inflate(context, R.layout.detail_course, null);
        TextView courseTitle = (TextView) v.findViewById(R.id.detail과목);
        TextView courseGrade = (TextView) v.findViewById(R.id.detail등급);
        TextView courseCredit = (TextView) v.findViewById(R.id.detail학점);
        courseTitle.setText(detailCourseList.get(i).getCourseTitle()+"과목");
        courseGrade.setText(detailCourseList.get(i).getCourseGrade()+"등급");
        courseCredit.setText(detailCourseList.get(i).getCourseCredit()+"학점");

        v.setTag(detailCourseList.get(i).getCourseTitle());
        return v;
    }

}
