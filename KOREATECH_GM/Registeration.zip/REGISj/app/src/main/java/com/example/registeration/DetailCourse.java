package com.example.registeration;

public class DetailCourse {
    int courseCredit;
    String courseTitle;
    String courseGrade;

    public DetailCourse(int courseCredit, String courseTitle, String courseGrade) {
        this.courseCredit = courseCredit;
        this.courseTitle = courseTitle;
        this.courseGrade = courseGrade;
    }

    public int getCourseCredit() {
        return courseCredit;
    }

    public void setCourseCredit(int courseCredit) {
        this.courseCredit = courseCredit;
    }

    public String getCourseTitle() {
        return courseTitle;
    }

    public void setCourseTitle(String courseTitle) {
        this.courseTitle = courseTitle;
    }

    public String getCourseGrade() {
        return courseGrade;
    }

    public void setCourseGrade(String courseGrade) {
        this.courseGrade = courseGrade;
    }





}
