package com.example.registeration;

import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link CourseFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link CourseFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class CourseFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private String userID=MainActivity.userID;
    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    //졸업요건 학점
    private TextView Gtotal;//총학점
    private TextView GHRDS;//HRD 선택
    private TextView GHRDR;//HRD 필수
    private TextView GgeneralS;//교양 선택
    private TextView GgeneralR;//교양 필수
    private TextView GmscS;//MSC 선택
    private TextView GmscR;//MSC 필수
    private TextView GmajorR;//전공 필수
    private TextView GmajorS;//전공 선택
    private TextView Gfree;// 자유학점
    //사용자 학점들
    private TextView total;//총학점
    private TextView HRDS;//HRD 선택
    private TextView HRDR;// HRD 필수
    private TextView generalS;// 교양 선택
    private TextView generalR;//교양 필수
    private TextView mscS;//MSC 선택
    private TextView mscR;// MSC 필수
    private TextView majorR;//전공 필수
    private TextView majorS;// 전공 선택
    private TextView free;// 자유학점

    private int totalnum;//총학점
    private int HRDSnum;//HRD 선택
    private int  HRDRnum;// HRD 필수
    private int  generalSnum;// 교양 선택
    private int generalRnum;//교양 필수
    private int mscSnum;//MSC 선택
    private int  mscRnum;// MSC 필수
    private int  majorRnum;//전공 필수
    private int majorSnum;// 전공 선택
    private int freenum;// 자유학점



    private OnFragmentInteractionListener mListener;

    public CourseFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment CourseFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static CourseFragment newInstance(String param1, String param2) {
        CourseFragment fragment = new CourseFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_course, container, false);
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }


}
